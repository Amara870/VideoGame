﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace VideoGame
{
    public class Warrior : Character
    {
        //private attributes of the lowercase naming convention
        private int jump;
        private int speed;


        //public Jump property
        public int Jump
        {
            get { return jump; }
            set
            {
                if (value < 0)
                {
                    jump = 0;
                }
                else
                {
                    jump = value;
                }
            }
        }

        //public Speed property
        public int Speed
        {
            get { return speed; }
            set
            {
                if (value < 0)
                {
                    speed = 0;
                }
                else
                {
                    speed = value;
                }
            }
        }

        //constructor for the Wizard subclass
        public Warrior(int new_attack, int new_health, string new_name, int new_defense, int new_stamina, int new_jump, int new_speed)
            : base(new_attack, new_health, new_name, new_defense, new_stamina)
        {
            Jump = new_jump;
            Speed = new_speed;
        }

        public void Dodge()
        {
            if (Speed > 0)
            {
                MessageBox.Show($"{Name} dodges out of the way with {Speed} speed!");
                Stamina -= 10; // Decrease stamina by 10 for each dodge
            }
            else
            {
                MessageBox.Show($"{Name} has no stamina left to dodge!");
            }
        }
    }
}
