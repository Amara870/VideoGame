namespace VideoGame
{
    public partial class FRMCharacter : Form
    {
        public FRMCharacter()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            /* Character newCharacter = new Character(100, 5, "Mar", 0, 50);
             MessageBox.Show($"Welcome {newCharacter.Name}! Your stats are: {newCharacter.Health} health, {newCharacter.Attack} attack damage, and {newCharacter.Stamina} stamina."); */

            //create an object with hard-coded values

            //string name
            string name = txtName.Text;
            //int attack
            int attack = (int)nmAttack.Value;
            //int health
            int health = (int)nmHealth.Value;
            //int defense
            int defense = (int)nmDefense.Value;
            //int stmina
            int stamina = (int)nmStamina.Value;

            //int mana
            int mana = (int)nmMana.Value;
            //int magic
            int magic = (int)nmMagic.Value;

            //int jump
            int jump = (int)nmJump.Value;
            //int speed
            int speed = (int)nmSpeed.Value;



            //now create the object with the values from the user
            Character newCharacter = new Character(attack, health, name, defense, stamina);

            //new wizard object
            Wizard newWizard = new Wizard(attack, health, name, defense, stamina, mana, magic);

            //new warrior object
            Wizard newWarrior = new Wizard(attack, health, name, defense, stamina, jump, speed);

            //show the character's info in the listbox
            lstCharacters.Items.Add(newCharacter.DisplayInfo());

            lstCharacters.Items.Add(newWizard.DisplayInfo());

            lstCharacters.Items.Add(newWarrior.DisplayInfo());
        }

    }
}
