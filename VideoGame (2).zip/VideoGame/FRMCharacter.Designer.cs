﻿namespace VideoGame
{
    partial class FRMCharacter
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            lstCharacters = new ListBox();
            lblName = new Label();
            txtName = new TextBox();
            lblAttack = new Label();
            lblHealth = new Label();
            Defense = new Label();
            lblStamina = new Label();
            nmAttack = new NumericUpDown();
            nmHealth = new NumericUpDown();
            nmDefense = new NumericUpDown();
            nmStamina = new NumericUpDown();
            nmMagic = new NumericUpDown();
            nmMana = new NumericUpDown();
            lblMagic = new Label();
            lblMana = new Label();
            nmSpeed = new NumericUpDown();
            nmJump = new NumericUpDown();
            lblSpeed = new Label();
            lblJump = new Label();
            ((System.ComponentModel.ISupportInitialize)nmAttack).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmDefense).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmStamina).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmMagic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmMana).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmSpeed).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmJump).BeginInit();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(319, 359);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(94, 29);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create Character";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // lstCharacters
            // 
            lstCharacters.FormattingEnabled = true;
            lstCharacters.Location = new Point(159, 416);
            lstCharacters.Margin = new Padding(2);
            lstCharacters.Name = "lstCharacters";
            lstCharacters.Size = new Size(452, 144);
            lstCharacters.TabIndex = 1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(178, 34);
            lblName.Margin = new Padding(2, 0, 2, 0);
            lblName.Name = "lblName";
            lblName.Size = new Size(119, 20);
            lblName.TabIndex = 2;
            lblName.Text = "Character Name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(312, 34);
            txtName.Margin = new Padding(2);
            txtName.Name = "txtName";
            txtName.Size = new Size(121, 27);
            txtName.TabIndex = 3;
            // 
            // lblAttack
            // 
            lblAttack.AutoSize = true;
            lblAttack.Location = new Point(243, 85);
            lblAttack.Margin = new Padding(2, 0, 2, 0);
            lblAttack.Name = "lblAttack";
            lblAttack.Size = new Size(54, 20);
            lblAttack.TabIndex = 4;
            lblAttack.Text = "Attack:";
            // 
            // lblHealth
            // 
            lblHealth.AutoSize = true;
            lblHealth.Location = new Point(243, 122);
            lblHealth.Margin = new Padding(2, 0, 2, 0);
            lblHealth.Name = "lblHealth";
            lblHealth.Size = new Size(56, 20);
            lblHealth.TabIndex = 5;
            lblHealth.Text = "Health:";
            // 
            // Defense
            // 
            Defense.AutoSize = true;
            Defense.Location = new Point(232, 153);
            Defense.Margin = new Padding(2, 0, 2, 0);
            Defense.Name = "Defense";
            Defense.Size = new Size(66, 20);
            Defense.TabIndex = 6;
            Defense.Text = "Defense:";
            // 
            // lblStamina
            // 
            lblStamina.AutoSize = true;
            lblStamina.Location = new Point(233, 188);
            lblStamina.Margin = new Padding(2, 0, 2, 0);
            lblStamina.Name = "lblStamina";
            lblStamina.Size = new Size(66, 20);
            lblStamina.TabIndex = 7;
            lblStamina.Text = "Stamina:";
            // 
            // nmAttack
            // 
            nmAttack.Location = new Point(311, 80);
            nmAttack.Margin = new Padding(2);
            nmAttack.Name = "nmAttack";
            nmAttack.Size = new Size(122, 27);
            nmAttack.TabIndex = 8;
            // 
            // nmHealth
            // 
            nmHealth.Location = new Point(311, 120);
            nmHealth.Margin = new Padding(2);
            nmHealth.Name = "nmHealth";
            nmHealth.Size = new Size(122, 27);
            nmHealth.TabIndex = 9;
            // 
            // nmDefense
            // 
            nmDefense.Location = new Point(311, 153);
            nmDefense.Margin = new Padding(2);
            nmDefense.Name = "nmDefense";
            nmDefense.Size = new Size(122, 27);
            nmDefense.TabIndex = 10;
            // 
            // nmStamina
            // 
            nmStamina.Location = new Point(311, 183);
            nmStamina.Margin = new Padding(2);
            nmStamina.Name = "nmStamina";
            nmStamina.Size = new Size(122, 27);
            nmStamina.TabIndex = 11;
            // 
            // nmMagic
            // 
            nmMagic.Location = new Point(312, 248);
            nmMagic.Margin = new Padding(2);
            nmMagic.Name = "nmMagic";
            nmMagic.Size = new Size(122, 27);
            nmMagic.TabIndex = 15;
            // 
            // nmMana
            // 
            nmMana.Location = new Point(312, 218);
            nmMana.Margin = new Padding(2);
            nmMana.Name = "nmMana";
            nmMana.Size = new Size(122, 27);
            nmMana.TabIndex = 14;
            // 
            // lblMagic
            // 
            lblMagic.AutoSize = true;
            lblMagic.Location = new Point(239, 255);
            lblMagic.Margin = new Padding(2, 0, 2, 0);
            lblMagic.Name = "lblMagic";
            lblMagic.Size = new Size(53, 20);
            lblMagic.TabIndex = 13;
            lblMagic.Text = "Magic:";
            // 
            // lblMana
            // 
            lblMana.AutoSize = true;
            lblMana.Location = new Point(243, 220);
            lblMana.Margin = new Padding(2, 0, 2, 0);
            lblMana.Name = "lblMana";
            lblMana.Size = new Size(49, 20);
            lblMana.TabIndex = 12;
            lblMana.Text = "Mana:";
            // 
            // nmSpeed
            // 
            nmSpeed.Location = new Point(312, 314);
            nmSpeed.Margin = new Padding(2);
            nmSpeed.Name = "nmSpeed";
            nmSpeed.Size = new Size(122, 27);
            nmSpeed.TabIndex = 19;
            // 
            // nmJump
            // 
            nmJump.Location = new Point(312, 284);
            nmJump.Margin = new Padding(2);
            nmJump.Name = "nmJump";
            nmJump.Size = new Size(122, 27);
            nmJump.TabIndex = 18;
            // 
            // lblSpeed
            // 
            lblSpeed.AutoSize = true;
            lblSpeed.Location = new Point(238, 316);
            lblSpeed.Margin = new Padding(2, 0, 2, 0);
            lblSpeed.Name = "lblSpeed";
            lblSpeed.Size = new Size(54, 20);
            lblSpeed.TabIndex = 17;
            lblSpeed.Text = "Speed:";
            // 
            // lblJump
            // 
            lblJump.AutoSize = true;
            lblJump.Location = new Point(239, 286);
            lblJump.Margin = new Padding(2, 0, 2, 0);
            lblJump.Name = "lblJump";
            lblJump.Size = new Size(47, 20);
            lblJump.TabIndex = 16;
            lblJump.Text = "Jump:";
            // 
            // FRMCharacter
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 603);
            Controls.Add(nmSpeed);
            Controls.Add(nmJump);
            Controls.Add(lblSpeed);
            Controls.Add(lblJump);
            Controls.Add(nmMagic);
            Controls.Add(nmMana);
            Controls.Add(lblMagic);
            Controls.Add(lblMana);
            Controls.Add(nmStamina);
            Controls.Add(nmDefense);
            Controls.Add(nmHealth);
            Controls.Add(nmAttack);
            Controls.Add(lblStamina);
            Controls.Add(Defense);
            Controls.Add(lblHealth);
            Controls.Add(lblAttack);
            Controls.Add(txtName);
            Controls.Add(lblName);
            Controls.Add(lstCharacters);
            Controls.Add(btnCreate);
            Name = "FRMCharacter";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)nmAttack).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmDefense).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmStamina).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmMagic).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmMana).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmSpeed).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmJump).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private ListBox lstCharacters;
        private Label lblName;
        private TextBox txtName;
        private Label lblAttack;
        private Label lblHealth;
        private Label Defense;
        private Label lblStamina;
        private NumericUpDown nmAttack;
        private NumericUpDown nmHealth;
        private NumericUpDown nmDefense;
        private NumericUpDown nmStamina;
        private NumericUpDown nmMagic;
        private NumericUpDown nmMana;
        private Label lblMagic;
        private Label lblMana;
        private NumericUpDown nmSpeed;
        private NumericUpDown nmJump;
        private Label lblSpeed;
        private Label lblJump;
    }
}
