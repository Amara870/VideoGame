﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoGame
{
    //the name of the subclass (child) : the name of the baseclass (parent)
    public class Wizard : Character
    {
        //private attributes of the lowercase naming convention
        private int mana;
        private int magic;

        //public Mana property
        public int Mana
        {
            get { return mana; }
            set
            {
                if (value < 0)
                {
                    mana = 0;
                }
                else
                {
                    mana = value;
                }
            }
        }

        //public Magic property
        public int Magic
        {
            get { return magic; }
            set
            {
                if (value < 0)
                {
                    magic = 0;
                }
                else
                {
                    magic = value;
                }
            }
        }

        //constructor for the Wizard subclass
        public Wizard(int new_attack, int new_health, string new_name, int new_defense, int new_stamina, int new_mana, int new_magic)
            : base(new_attack, new_health, new_name, new_defense, new_stamina)
        {
            Mana = new_mana;
            Magic = new_magic;
        }

        //show an action message
        public void CastSpell()
        {
            if (Mana > 0)
            {
                MessageBox.Show($"{Name} casts a spell with {Magic} magic power!");
                Mana -= 10; // Decrease mana by 10 for each spell cast
            }
            else
            {
                MessageBox.Show($"{Name} has no mana left to cast a spell!");
            }
        }
    }
}
