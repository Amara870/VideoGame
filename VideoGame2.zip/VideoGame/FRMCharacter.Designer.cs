﻿namespace VideoGame
{
    partial class FRMCharacter
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            lstCharacters = new ListBox();
            lblName = new Label();
            txtName = new TextBox();
            lblAttack = new Label();
            lblHealth = new Label();
            Defense = new Label();
            lblStamina = new Label();
            nmAttack = new NumericUpDown();
            nmHealth = new NumericUpDown();
            nmDefense = new NumericUpDown();
            nmStamina = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nmAttack).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmDefense).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmStamina).BeginInit();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(390, 281);
            btnCreate.Margin = new Padding(4);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(118, 36);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create Character";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // lstCharacters
            // 
            lstCharacters.FormattingEnabled = true;
            lstCharacters.ItemHeight = 25;
            lstCharacters.Location = new Point(190, 352);
            lstCharacters.Name = "lstCharacters";
            lstCharacters.Size = new Size(564, 179);
            lstCharacters.TabIndex = 1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(223, 42);
            lblName.Name = "lblName";
            lblName.Size = new Size(142, 25);
            lblName.TabIndex = 2;
            lblName.Text = "Character Name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(390, 42);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 31);
            txtName.TabIndex = 3;
            // 
            // lblAttack
            // 
            lblAttack.AutoSize = true;
            lblAttack.Location = new Point(303, 91);
            lblAttack.Name = "lblAttack";
            lblAttack.Size = new Size(66, 25);
            lblAttack.TabIndex = 4;
            lblAttack.Text = "Attack:";
            // 
            // lblHealth
            // 
            lblHealth.AutoSize = true;
            lblHealth.Location = new Point(302, 137);
            lblHealth.Name = "lblHealth";
            lblHealth.Size = new Size(67, 25);
            lblHealth.TabIndex = 5;
            lblHealth.Text = "Health:";
            // 
            // Defense
            // 
            Defense.AutoSize = true;
            Defense.Location = new Point(289, 176);
            Defense.Name = "Defense";
            Defense.Size = new Size(80, 25);
            Defense.TabIndex = 6;
            Defense.Text = "Defense:";
            // 
            // lblStamina
            // 
            lblStamina.AutoSize = true;
            lblStamina.Location = new Point(290, 220);
            lblStamina.Name = "lblStamina";
            lblStamina.Size = new Size(79, 25);
            lblStamina.TabIndex = 7;
            lblStamina.Text = "Stamina:";
            // 
            // nmAttack
            // 
            nmAttack.Location = new Point(387, 85);
            nmAttack.Name = "nmAttack";
            nmAttack.Size = new Size(153, 31);
            nmAttack.TabIndex = 8;
            // 
            // nmHealth
            // 
            nmHealth.Location = new Point(387, 135);
            nmHealth.Name = "nmHealth";
            nmHealth.Size = new Size(153, 31);
            nmHealth.TabIndex = 9;
            // 
            // nmDefense
            // 
            nmDefense.Location = new Point(387, 176);
            nmDefense.Name = "nmDefense";
            nmDefense.Size = new Size(153, 31);
            nmDefense.TabIndex = 10;
            // 
            // nmStamina
            // 
            nmStamina.Location = new Point(387, 214);
            nmStamina.Name = "nmStamina";
            nmStamina.Size = new Size(153, 31);
            nmStamina.TabIndex = 11;
            // 
            // FRMCharacter
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 562);
            Controls.Add(nmStamina);
            Controls.Add(nmDefense);
            Controls.Add(nmHealth);
            Controls.Add(nmAttack);
            Controls.Add(lblStamina);
            Controls.Add(Defense);
            Controls.Add(lblHealth);
            Controls.Add(lblAttack);
            Controls.Add(txtName);
            Controls.Add(lblName);
            Controls.Add(lstCharacters);
            Controls.Add(btnCreate);
            Margin = new Padding(4);
            Name = "FRMCharacter";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)nmAttack).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmDefense).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmStamina).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private ListBox lstCharacters;
        private Label lblName;
        private TextBox txtName;
        private Label lblAttack;
        private Label lblHealth;
        private Label Defense;
        private Label lblStamina;
        private NumericUpDown nmAttack;
        private NumericUpDown nmHealth;
        private NumericUpDown nmDefense;
        private NumericUpDown nmStamina;
    }
}
