﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoGame
{
    public class Character
    {
        //private field attributes
        private int attack;
        private string name;
        private int health;
        private int defense;
        private int stamina;

        //public properties
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }

        public int Stamina
        {
            get { return stamina; }
            set { stamina = value; }
        }

        //Constructor - generally pass in each attribute if that makes sense for your program
        public Character(int attack, int health, string name, int defense, int stamina)
        {
            Attack = attack;
            Name = name;
            Health = health;
            Defense = defense;
            Stamina = stamina;
        }

        //method to display the character's info
        public string DisplayInfo()
        {
            //return a formatted string with all of the character's info; return only what we think is necessary for the object to display
            return $"{Name} has {Health} health and {Defense} defense and {Attack} attack and {Stamina} stamina";
        }
    }
}
